import 'package:transcriber_whisper/models/segment.dart';

class Transcription {
  final List<Segment> transsegments;
  List<Segment>? realsegments;
  List<Segment>? transdiffsegments;
  final String? fulltext;
  List<String>? listWordsTrascription;
  List<String>? listWordsTexto;

  Transcription({required this.transsegments, this.realsegments, this.transdiffsegments, this.fulltext, this.listWordsTrascription, this.listWordsTexto});

  factory Transcription.fromListMap(dynamic listmap, {bool generateFullText = true, String text = ""}) {
    List<Segment> transsegments = [];
    List<Segment> realsegments = [];
    List<Segment> transdiffsegments = [];
    String fullTextTranscription = "";
    List<String> textoEscritoListwords = [""];
    List<String> transcriptionListwords = [""];

    if (text.isNotEmpty) {
      // Remove punctuation
      text = text.replaceAll(RegExp(r'[^\w\s]'), '');
      // Replace multiple spaces with single space
      text = text.replaceAll(RegExp(r'\s+'), ' ');
      // Replace newlines with single space
      text = text.replaceAll(RegExp(r'[\r\n]+'), ' ');
      // Trim leading and trailing whitespace
      text = text.trim();
      // Put each word on a new line
      text = text.split(' ').where((word) => word.isNotEmpty).join('\n');
      List<String> lines = text.split('\n');
      textoEscritoListwords = lines;

      //print(textoEscritoListwords.asMap());
    }

    if (listmap is List) {
      print("segmentos previstos en texto original: ${textoEscritoListwords.length}");
      //print(textoEscritoListwords);
      print("segmentos previstos en la trascripción: ${listmap.length}");
      //print("eeeeeeeeeeeeeeeeeeeeeeeeee: ${textoEscritoListwords}");

      for (var e in listmap) {
        if (e is Map<String, dynamic>) {
          Segment segment = Segment.fromMap(e);
          //segment.word = segment.word.replaceAll(RegExp(r'[^\w\s]'), '');
          transsegments.add(segment);

          String word = e["word"];
          // Remove punctuation
          word = word.replaceAll(RegExp(r'[^\w\s]'), '');
          // Replace multiple spaces with single space
          word = word.replaceAll(RegExp(r'\s+'), ' ');
          // Replace newlines with single space
          word = word.replaceAll(RegExp(r'[\r\n]+'), ' ');
          // Trim leading and trailing whitespace
          word = word.trim();
          word = word.toLowerCase();
          //print("palabras en transcription: ${word}");

          transcriptionListwords.add(word);

          if (generateFullText) {
            fullTextTranscription += "${e["word"]} ";
          }
        } else {
          throw FormatException("Error: Elemento no es un mapa: $e");
        }
      }

      if (textoEscritoListwords.isNotEmpty) {
        // Iterate over the words in the written text
        int segmentIndex = 0;
        double currentTime = 0.0;
        for (String writtenWord in textoEscritoListwords) {
          bool foundMatch = false;
          realsegments.add(Segment(start: 0, end: 0, word: writtenWord, probability: 0.0));
        }
      }
    } else {
      throw FormatException("Error: No es una lista");
    }
    /*print("Palabras en transcription:");
    for(Segment w in segments){
      print(w.word);
    }
    print("Palabras en texto real:");
    for(Segment w in realsegments){
      print(w.word);
    }*/
    //print("palabras en transcription: ${word}");
    return Transcription(
      transsegments: transsegments,
      realsegments: text.isNotEmpty ? realsegments : null,
      fulltext: generateFullText ? fullTextTranscription : null,
      listWordsTrascription: transcriptionListwords,
      listWordsTexto: textoEscritoListwords,
    );
  }

  Transcription copyWith({
    List<Segment>? transsegments,
    List<Segment>? realsegments,
    List<Segment>? transdiffsegments,
    String? fulltext,
    List<String>? listWordsTrascription,
    List<String>? listWordsTexto,
  }) {
    return Transcription(
      transsegments: transsegments ?? this.transsegments,
      realsegments: realsegments ?? this.realsegments,
      transdiffsegments: transdiffsegments ?? this.transdiffsegments,
      fulltext: fulltext ?? this.fulltext,
      listWordsTrascription: listWordsTrascription ?? this.listWordsTrascription,
      listWordsTexto: listWordsTexto ?? this.listWordsTexto,
    );
  }
}
