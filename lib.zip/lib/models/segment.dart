import 'package:transcriber_whisper/models/word_with_spans.dart';

class Segment {
  final double start;
  final double end;
  final String word;
  final double probability;
  List<String> tags;
  WordWithSpans? wordWithSpans;

  Segment({required this.start, required this.end, required this.word, required this.probability, List<String>? tags, this.wordWithSpans})
    : tags = tags ?? []; // Initialize tags as an empty list if null

  factory Segment.fromMap(Map<String, dynamic> map) {
    return Segment(
      start: map['start'] as double,
      end: map['end'] as double,
      word: map['word'].replaceAll(RegExp(r'[^\w\s]'), '') as String,
      probability: map['probability'] as double,
    );
  }

  factory Segment.fromMap2(Map<String, dynamic> map, String text) {
    return Segment(start: map['start'] as double, end: map['end'] as double, word: map['word'] as String, probability: map['probability'] as double);
  }

  Segment copyWith({double? start, double? end, String? word, String? realword, double? probability, List<String>? tags, WordWithSpans? wordWithSpans}) {
    return Segment(
      start: start ?? this.start,
      end: end ?? this.end,
      word: word ?? this.word,
      probability: probability ?? this.probability,
      tags: tags ?? this.tags,
      wordWithSpans: wordWithSpans ?? this.wordWithSpans,
    );
  }
}
